Example Submission #1

To use this project, you can click "run" which should activate both the accelerometer and roll/pitch graphs.
You can turn the filter on and off in real-time, and adjust the smoothing factor/cutoff in real-time as well. 
Clicking the loop stop button will cause the array to populate and be displayed in the array indicator before the code finishes running. 
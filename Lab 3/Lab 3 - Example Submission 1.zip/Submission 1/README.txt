Author: Adam Cavatassi, McGill University, 2018
Example submission for Lab 3

To run my project, import the Position-Net weights by running load_from_file.vi with #hidden layers set to 1.
Select weights_input_h0.csv, weights_h0_out.csv in that order. You will be prompted for two more file selections, but just select
the same files. The extra two loads are for the data set, which you should not worry about. My full code is actually Lab 3 and Lab 4 combined, but I have removed most of the Lab 4 material so that you cannot steal my work. 

Once you have imported the weights, run lab_3.vi. The code will pause until you click START INFERENCE under the inference section of the front panel. Weights Source should be ON.
Next you will see the x, y, z, roll, and pitch plots become active and the LEDs on the myRIO will be on. The neural network is now running for you to verify that my positions are accurately detected.

Enjoy!
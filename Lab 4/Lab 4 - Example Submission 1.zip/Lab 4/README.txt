This is the README or the good example. 

To run my project, be sure to first connect to you myRIO. Then, run the load_from_file.vi. You will be prompted to load 4 files.
The first two files to be loaded are weight matrices, but these are not needed for this lab. When prompted the first two times, simply click CANCEL.
LabVIEW will get mad at you and ask if you want to continue. Say CONTINUE. Once you are prompted for the third file load, load the file input_data.csv,
located in ./lab_4_files. For the fourth and final prompt, load the file targets.csv in the same directory. 

Now you can run the main code, which is the VI titled lab_4.vi. Once you open this VI, a few switches in the front panel must be correctly set. 
Under MAIN CONTROL, be sure that MODE INITIALIZE is set to "network_train". Next, under TRAINING CONTROL, make sure that DATA SOURCE is ON,
indicating that the training data will be read fom the shared variable. Make sure that the # of hidden layers is set to 1, the # nodes per hidden layer
is iset to 8, the # of inputs is set to 5, and the # outputs is set to 3. The learning rate should be set to 0.01, and the validation split should be 
set to 0.2. WRITE WEIGHTS should be off, and ACTIVATION should be off, indicating that the sigmoid function will be used. Under INFERENCE, make sure that
WEIGHTS SOURCE is set to OFF, indicating that local weight data will be used. Once this is all be set up, you can run the code. 

Once the code is running, the MODE STATUS should read "Training Mode". Under TRAINING CONTROL, you can then click START TRAINING, and the training will begin.
You will be able to watch the training and validation loss drop over several iterations. Once the loss has dropped sufficiently low (<0.03), you can
click STOP TRAINING. You can then move to inference mode by clicking BEGIN INFERENCE MODE. THE MODE STATUS should then read "Inference Mode". You can
then click START INFERENCE, and you will be able to see the LEDs on the myRIO light up. They should reflect the correct position. 